import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent {
  hero = {
    title: 'La esencia de la Tierra de Cádiz',
    subtitle: 'Descubre lo mejor de nuestra cocina a la parrilla.'
  };

  essence = {
    title: 'La esencia del sur',
    description: 'Comer en uno de nuestros restaurantes Fogón de Mariana de Cádiz, San Fernando, Jerez o Chiclana es dejarte envolver por los campos del sur. Nuestros espacios están diseñados para ofrecerte una experiencia cálida y acogedora que celebra la autenticidad de nuestra tierra.',
    buttonText: 'Reserva'
  };

  flavor = {
    title: 'Sabor y Brasas',
    description: 'Nuestra cocina tradicional renovada de la Tierra de Cádiz cobra vida en cada plato, que preparamos con un respeto profundo por el producto. Hortalizas frescas de Navazo, verduras de las huertas de Conil y ternera especial de la Janda, que aquí encuentra su máxima expresión en la parrilla.',
    buttonText: 'Carta'
  };

  authentic = {
    title: 'Sabores auténticos, tradición renovada',
    description: 'Desde 1988 nos dedicamos a capturar los auténticos sabores de los campos gaditanos, rendir homenaje a su tradición, a la rica herencia culinaria de nuestra tierra, combinando el recetario de siempre con un toque moderno.',
    buttonText: 'Nosotros'
  };

  reviews = [
    { name: 'Diego S', comment: 'Cada una de muchas veces que hemos venido, la experiencia va superando a la anterior.', rating: 5 },
    { name: 'Rocío Márquez Palomino', comment: 'El salmorejo y la tabla de jamón estaban deliciosos.', rating: 5 },
    { name: 'David R', comment: 'Buena calidad de la carne y buen ambiente, volveremos.', rating: 5 }
  ];
}



