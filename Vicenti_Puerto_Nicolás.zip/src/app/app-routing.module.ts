import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { TrabajoComponent } from './pages/trabajo/trabajo.component';

const routes: Routes = [
  { path: '', redirectTo: '/inicio', pathMatch: 'full' }, // Redirección para la raíz
  { path: 'inicio', component: HomeComponent }, // Ruta para la página de inicio
  { path: 'trabajo', component: TrabajoComponent } // Ruta para Trabajo
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}




