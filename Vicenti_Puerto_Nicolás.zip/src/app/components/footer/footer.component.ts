import { Component } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent {
  socialLinks = [
    { icon: 'fab fa-facebook', url: 'https://facebook.com' },
    { icon: 'fab fa-instagram', url: 'https://instagram.com' },
    { icon: 'fab fa-twitter', url: 'https://twitter.com' }
  ];
}


