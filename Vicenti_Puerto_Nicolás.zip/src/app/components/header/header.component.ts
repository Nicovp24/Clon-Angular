import { Component } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent {
  navLinks = [
    { label: 'Reserva & Restaurantes', url: '/reservas' },
    { label: 'Carta', url: '/carta' },
    { label: 'Nosotros', url: '/nosotros' },
    { label: 'Reservas Eventos', url: '/eventos' },
    { label: 'Regala', url: '/regala' },
    { label: 'Trabajo', url: '/trabajo' }
  ];
}


